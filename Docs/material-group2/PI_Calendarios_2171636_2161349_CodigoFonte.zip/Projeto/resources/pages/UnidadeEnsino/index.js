import React from "react";

const UnidadeEnsino = () => {
  return <>UnidadeEnsino</>;
};

export default UnidadeEnsino;
