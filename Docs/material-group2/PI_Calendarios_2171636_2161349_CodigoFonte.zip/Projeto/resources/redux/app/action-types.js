const baseType = "APP";

const types = {
  SET_ACADEMIC_YEAR: `${baseType}/SET_ACADEMIC_YEAR`,
  LOGOUT: `${baseType}/LOGOUT`,
};

export default types;
