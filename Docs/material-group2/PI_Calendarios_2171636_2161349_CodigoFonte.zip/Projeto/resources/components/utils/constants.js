export const SEMESTER = {
  FIRST: "1",
  SECOND: "2",
  SPECIAL: "3",
};
