<?php

namespace App\Http\Controllers;


class ReactController extends Controller
{
    public function index()
    {
        return view('react.index');
    }
}
